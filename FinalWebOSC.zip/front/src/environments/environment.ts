export const environment = {
  production: false,
  apiUrl: 'http://localhost:8000',
  mediaUrl: 'http://localhost:8000'  // Add this line
};
