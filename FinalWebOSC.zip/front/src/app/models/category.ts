// src/app/models/category.ts
export interface Category {
    id: number;
    name: string;
  }
  