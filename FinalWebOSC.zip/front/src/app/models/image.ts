// src/app/models/image.ts
export interface Image {
    id: number;
    image: string; // URL or path to the image
  }
  